import socket, threading
host = '127.0.0.1' #호스팅 IP
port = 8024 #호스팅 port

main_server_in_port = 8022

#def
#server_in_data = 0


def main_server_thread (main_client, main_addr):
    try:
        print('main server connect: ',main_addr)
        while True:
            server_in_data = main_server_socket.recv(1024)
            print('main_server_in: ',server_in_data.decode('utf-8'))
            #echo_return = 'echo: '+server_in_data.decode('utf-8')
            #main_server_socket.send(echo_return.encode('utf-8'))
    except:
        print("main_server except: ",main_addr)
    finally:
        print("main_server_socket is close")
        main_server_socket.close()

def socket_thread(client_socket, addr):
    print("connected by", addr)
    try:
        while True:
            data = client_socket.recv(1024)
            msg = data.decode('utf-8')
            print('Recv: ',msg)
            msg = 'echo: '+msg
            client_socket.send(msg.encode('utf-8'))
    except:
        print("excep: ",addr)
    finally:
        client_socket.close()

def going_to_server (ip,port):
    
    

try:
    main_server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    main_server_socket.bind((host,main_server_in_port))
    main_server_socket.listen(1)
    #while True:
    main_client, main_addr = main_server_socket.accept()
    main_tr = threading.Thread(target=socket_thread, args=(main_client,main_addr))
    main_tr.start()
except:
    print('main_server error')
finally:
    print('main_server close')
    main_server_socket.close()



try:
    server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    #서버 소캣 생성
    server_socket.bind((host,port))
    #서버 시작 (host = 127.0.0.1 , port = 8024)
    server_socket.listen(1)
    #서버 대기
    while True:
        #다중 클라이언트 접속을 위해 무한루프 사용
        client_socket, addr = server_socket.accept()
        #client_socket,addr 튜플로 소켓과 주소를 받음
        server_threading = threading.Thread(target=socket_thread,args=(client_socket,addr))
        #쓰레드로 넘겨줌
        server_threading.start()
        #쓰레드 시작
except:
    print('sub_server error')
finally:
    server_socket.close()